import * as Phaser from 'https://cdn.jsdelivr.net/npm/phaser@3/dist/phaser.esm.js';
import { SaveSystem } from '../system/saveSystem.js';

export default class BootScene extends Phaser.Scene {
  constructor() {
    super('Boot');
  }

  async create() {
    const saves = await SaveSystem.list();

    if (saves.length === 0) {
      // 没有任何存档 → 创建新存档
      this.scene.start('SaveCreate');
    } else {
      // 有存档 → 进入存档选择
      this.scene.start('SaveSelect');
    }
  }
}

