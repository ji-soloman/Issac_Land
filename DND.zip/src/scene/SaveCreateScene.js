// src/scenes/SaveCreateScene.js
import * as Phaser from 'https://cdn.jsdelivr.net/npm/phaser@3/dist/phaser.esm.js';
import { SaveSystem } from '../system/saveSystem.js';
import { createInitialWorld } from '../world/createInitialWorld.js';

export class SaveCreateScene extends Phaser.Scene {
  constructor() {
    super('SaveCreate');
  }

  async create() {
    // ⚠️ 这里先用写死数据，后面换成 UI 输入
    const options = {
      civilizationName: '阿尔泰文明',
      capitalName: '初火城',
      raceId: 'elf',
      tarotId: 'magician',
      developmentChoices: {
        district: true,
        trait: true,
        troop: false
      }
    };

    const world = createInitialWorld(options);

    const save = await SaveSystem.create(
      'slot1',
      options.civilizationName,
      world
    );

    this.scene.start('World', {
      slot: save.id,
      world: save.world
    });
  }
}
