// src/scene/SaveSelectScene.js
import * as Phaser from 'https://cdn.jsdelivr.net/npm/phaser@3/dist/phaser.esm.js';
import { SaveSystem } from '../system/saveSystem.js';

export class SaveSelectScene extends Phaser.Scene {
  constructor() {
    super('SaveSelect');
  }

  async create() {
    const saves = await SaveSystem.list();

    saves.forEach((save, i) => {
      this.add.text(100, 100 + i * 40, save.meta.name)
        .setInteractive()
        .on('pointerdown', async () => {
          const fullSave = await SaveSystem.load(save.id);
          this.scene.start('World', {
            slot: save.id,
            world: fullSave.world
          });
        });
    });
  }
}
